import os,pathlib,subprocess,sys
root=pathlib.Path(__file__).parent
work=root/'edge-work'
mode=sys.argv[1]
entry=sorted((work/'supabase/functions').glob('*/index.ts'))
shared=sorted((work/'supabase/functions/_shared').glob('*.ts'))
missing=[p.name for p in (work/'supabase/functions').iterdir() if p.is_dir() and p.name!='_shared' and not (p/'index.ts').exists()]
assert not missing,missing
assert entry
if mode=='check': command=['deno','check','--node-modules-dir=auto',*[str(p.relative_to(work)) for p in entry+shared]]
elif mode=='test': command=['deno','test','--no-check','--node-modules-dir=auto','supabase/functions/']
elif mode=='worker': command=['deno','check','--frozen','--node-modules-dir=none','--lock=supabase/workers/companion-push/deno.lock','supabase/workers/companion-push/supervisor.ts']
else: raise ValueError(mode)
print('mode',mode,'entrypoints',len(entry),'shared',len(shared),flush=True)
env=dict(os.environ);env['DENO_DIR']=str(root/'deno-cache')
sys.exit(subprocess.run(command,cwd=work,env=env,timeout=240).returncode)
