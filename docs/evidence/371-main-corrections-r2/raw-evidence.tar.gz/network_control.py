from pathlib import Path
import hashlib
import http.server
import json
import shutil
import subprocess
import threading

OUT = Path(__file__).parent
PROFILE = Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify-Web-App/root-companion-profile371-main-corrections/docs/evidence/web-local-fonts/tools/deny-remote.sb')
requests = []
class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        requests.append(self.path)
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'local-network-control')
    def log_message(self, *_args):
        pass

server = http.server.HTTPServer(('127.0.0.1', 0), Handler)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
code = '''const net=require('node:net'),http=require('node:http');
const remote=new Promise((resolve,reject)=>{
  const s=net.connect({host:'1.1.1.1',port:443});
  s.once('connect',()=>{s.destroy();reject(new Error('remote connection permitted'));});
  s.once('error',error=>error.code==='EPERM'?resolve(error.code):reject(error));
  s.setTimeout(2000,()=>{s.destroy();reject(new Error('no binding denial'));});
});
const local=new Promise((resolve,reject)=>{
  http.get('http://127.0.0.1:'+process.argv[1]+'/proof',response=>{
    let body='';response.on('data',part=>body+=part);response.on('end',()=>{
      if(response.statusCode===200&&body==='local-network-control')resolve({status:response.statusCode,bytes:body.length});
      else reject(new Error('wrong local response'));
    });
  }).on('error',reject);
});
Promise.all([remote,local]).then(result=>console.log(JSON.stringify({remote:result[0],local:result[1]}))).catch(error=>{console.error(error);process.exitCode=1;});
'''
try:
    command = ['/usr/bin/sandbox-exec', '-f', str(PROFILE), shutil.which('node'), '-e', code, str(server.server_port)]
    result = subprocess.run(command, capture_output=True, text=True, timeout=10)
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
record = {'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr, 'profile_sha256': hashlib.sha256(PROFILE.read_bytes()).hexdigest(), 'local_requests': requests, 'owned_server_stopped': not thread.is_alive()}
(OUT / 'network-control.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
assert result.returncode == 0 and requests == ['/proof'] and not thread.is_alive()
