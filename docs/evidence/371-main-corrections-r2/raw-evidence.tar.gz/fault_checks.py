from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess

ROOT = Path('/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify-Web-App/root-companion-profile371-main-corrections')
OUT = Path(__file__).parent
profile = ROOT / 'services/profile.ts'
hook = ROOT / 'hooks/useTaskActions.ts'
saved = {profile: profile.read_bytes(), hook: hook.read_bytes()}

def run(label, test):
    command = ['node', 'node_modules/vitest/vitest.mjs', 'run', test]
    with (OUT / (label + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=60)
    text = re.sub(r'\x1b\[[0-9;]*m', '', (OUT / (label + '.log')).read_text())
    record = {'command': command, 'exit_code': result.returncode, 'assertion_failure': 'AssertionError:' in text, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (OUT / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(label, result.returncode, record['assertion_failure'], flush=True)
    return record

records = []
try:
    profile.write_bytes(subprocess.check_output(['git', 'show', 'ca8f099a1f0541cb67ef6c9128faf829c5546ed7:services/profile.ts'], cwd=ROOT))
    records.append({'label': 'stage-red-final-null-fixture', **run('stage-red-final-null-fixture', 'services/profile.stageCache.test.ts')})
finally:
    profile.write_bytes(saved[profile])

profile_text = saved[profile].decode()
hook_text = saved[hook].decode()
date = '''    update = arrivalDate == null
      ? update.is("arrival_date", null)
      : update.eq("arrival_date", arrivalDate);
'''
stage = '''    update = storedStage == null
      ? update.is("stage", null)
      : update.eq("stage", String(storedStage));
'''
roots = '[CURRENT_USER_KEY, MODULES_KEY, LEARNING_PROGRESS_KEY]'
late_guard = '''          void queryClient.cancelQueries({ queryKey }).then(() => {
            if (!stillOwned({ accountId: userId, epoch })) return;
            return queryClient.invalidateQueries({ queryKey });
'''
faults = [
    ('fault-date-guard', profile, date, '', 'services/profile.stageCache.test.ts'),
    ('fault-stage-guard', profile, stage, '', 'services/profile.stageCache.test.ts'),
    ('fault-null-filter', profile, '.is("stage", null)', '.eq("stage", "null")', 'services/profile.stageCache.test.ts'),
    ('fault-modules-refresh', hook, roots, '[CURRENT_USER_KEY, LEARNING_PROGRESS_KEY]', 'hooks/profileLearnRefresh.test.tsx'),
    ('fault-summary-refresh', hook, roots, '[CURRENT_USER_KEY, MODULES_KEY]', 'hooks/profileLearnRefresh.test.tsx'),
    ('fault-profile-refresh', hook, roots, '[MODULES_KEY, LEARNING_PROGRESS_KEY]', 'hooks/profileLearnRefresh.test.tsx'),
    ('fault-cancel-old-read', hook, 'void queryClient.cancelQueries({ queryKey }).then(() => {', 'void Promise.resolve().then(() => {', 'hooks/profileLearnRefresh.test.tsx'),
    ('fault-late-owner-guard', hook, late_guard, late_guard.replace('            if (!stillOwned({ accountId: userId, epoch })) return;\n', ''), 'hooks/profileLearnRefresh.test.tsx'),
]
for label, path, old, new, test in faults:
    try:
        text = saved[path].decode()
        assert text.count(old) == 1, (label, text.count(old))
        path.write_text(text.replace(old, new))
        records.append({'label': label, **run(label, test)})
    finally:
        path.write_bytes(saved[path])

for path, data in saved.items():
    assert path.read_bytes() == data
restoration = {str(path.relative_to(ROOT)): hashlib.sha256(data).hexdigest() for path, data in saved.items()}
(OUT / 'fault-results.json').write_text(json.dumps({'results': records, 'restored': restoration}, indent=2) + '\n')
assert all(row['exit_code'] != 0 and row['assertion_failure'] for row in records), records
print('All required assertion failures observed; source restored.', flush=True)
