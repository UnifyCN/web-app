import { afterEach, beforeEach, expect, it, vi } from 'vitest';
const state = vi.hoisted(() => ({
  row: {} as Record<string, any>, holdUser: null as Promise<void> | null,
  queries: [] as any[], writes: [] as any[], stages: [] as string[], sent: [] as any[],
}));
vi.mock('@/lib/supabase/client', () => ({
  isSupabaseConfigured: () => true,
  getAuthUserId: async () => 'synthetic-stage-review',
  createClient: () => ({
    auth: {getSession: async () => ({data:{session:{user:{id:'synthetic-stage-review'}}}})},
    from: (table: string) => {
      let patch: any = null;
      const predicates: any[] = [];
      const query: any = {
        select: () => query, order: () => query,
        update: (value: any) => {patch = value; return query;},
        eq: (key: string, value: any) => {predicates.push([key,value]); return query;},
        is: (key: string, value: any) => {predicates.push([key,value]); return query;},
        maybeSingle: async () => {
          const snapshot = {...state.row};
          if (table === 'users') {
            const wait = state.holdUser; state.holdUser = null;
            if (wait) await wait;
            return {data:{id:'synthetic-stage-review', username:'synthetic-review', permissions:null},error:null};
          }
          return {data:snapshot,error:null};
        },
        then: (yes: any, no: any) => {
          if (patch) {
            const applies = predicates.every(([key,value]) => key === 'id' || state.row[key] === value);
            state.writes.push({patch,predicates,applies});
            if (applies) Object.assign(state.row,patch);
            return Promise.resolve({data:null,error:null}).then(yes,no);
          }
          return Promise.resolve({data:[],count:0,error:null}).then(yes,no);
        },
      };
      state.queries.push({table,predicates});
      return query;
    },
  }),
}));
vi.mock('@/lib/sanity', () => ({
  MODULES_LIST_QUERY:'', isSanityConfigured: () => false,
  sanityClient:{fetch: async (_q: string, args: any) => {state.stages.push(args.stage); return [];}},
  mergeI18nOverlay:(row:any) => row,
}));
import { getCurrentUser } from '/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify-Web-App/root-companion-profile371-main-corrections/services/profile';
import { getTasks } from '/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify-Web-App/root-companion-profile371-main-corrections/services/checklist';
import { createTaskActionClient } from '/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify-Web-App/root-companion-profile371-main-corrections/lib/companionActions/client';
import { calculateUserStage } from '@/lib/onboarding/calculateUserStage';
import { needsArrivalPrompt } from '@/lib/onboarding/arrivalPrompt';

const client = createTaskActionClient({platform:'web',appVersion:'synthetic-review',transport:async body => {
  state.sent.push(body);
  const undo = body.action === 'undo';
  expect(['apply','undo']).toContain(body.action);
  const operation = undo ? {field:'arrival_date',value:null} : (body.operations as any[])[0];
  const before = state.row.arrival_date;
  state.row.arrival_date = operation.value;
  // Exact #371 apply_profile null/date stage rule, migration lines 286-292.
  state.row.stage = String(operation.value === null ? 0 : calculateUserStage(operation.value));
  state.row.companion_field_revisions.arrival_date++;
  return {status:200,body:{replayed:false,receipt:{
    operation_id:body.operation_id,operation_type:'profile.update',created_at:new Date().toISOString(),
    kind:undo?'undo':'change',undo_of:undo?body.receipt_operation_id:null,task_ref:null,
    before_revision:state.row.companion_field_revisions.arrival_date-1,
    after_revision:state.row.companion_field_revisions.arrival_date,
    undone_by:null,current:true,undoable:!undo,
    profile:{field:'arrival_date',before,after:operation.value},
  }}};
}});
beforeEach(() => {
  vi.useFakeTimers(); vi.setSystemTime(new Date('2026-10-30T12:00:00-07:00'));
  state.row = {id:'synthetic-stage-review',persona:'skilled_worker',province:'Ontario',arrival_date:null,stage:'0',
    companion_field_revisions:{province:1,arrival_date:1,city:1}};
  state.holdUser=null; state.queries=[]; state.writes=[]; state.stages=[]; state.sent=[];
});
afterEach(() => vi.useRealTimers());
async function applyDate(value: string, id: string) {
  const result = await client.apply(id,{type:'profile.update',field:'arrival_date',value,
    expected_revision:state.row.companion_field_revisions.arrival_date},
    {kind:'approved_proposal',proposal_id:'synthetic-approved-review',proposal_revision:1});
  expect(result.kind).toBe('applied');
}
async function oldReadAfterMonthBoundary() {
  await applyDate('2026-07-31','synthetic-save-1');
  expect(state.row.stage).toBe('1');
  vi.setSystemTime(new Date('2026-10-31T12:00:00-07:00'));
  let release!: () => void;
  state.holdUser = new Promise<void>(resolve => {release=resolve;});
  const oldRead = getCurrentUser();
  // Drain getSession and the parallel database reads, but keep users response pending.
  for (let i=0;i<8;i++) await Promise.resolve();
  expect(state.queries.some(query => query.table === 'user_onboarding_profiles')).toBe(true);
  return {oldRead,release};
}
it('control: dateless legacy stage zero stays on its track and keeps the prompt', async () => {
  const profile = await getCurrentUser(); await getTasks();
  expect(profile?.onboarding?.stage).toBe(0);
  expect(needsArrivalPrompt(profile?.onboarding ?? null)).toBe(true);
  expect(state.stages).toEqual(['not_arrived']); expect(state.writes).toEqual([]);
});
it('control: a usable new date still selects the right track after a stale cache write', async () => {
  const {oldRead,release} = await oldReadAfterMonthBoundary();
  await applyDate('2028-02-01','synthetic-save-2');
  release(); await oldRead; for(let i=0;i<8;i++) await Promise.resolve();
  await getTasks(); const fresh = await getCurrentUser();
  expect(fresh?.onboarding?.stage).toBe(0); expect(state.stages).toEqual(['not_arrived']);
});
it('retains restored legacy stage zero after an older profile read completes', async () => {
  const {oldRead,release} = await oldReadAfterMonthBoundary();
  expect((await client.undo('synthetic-undo','synthetic-save-1')).kind).toBe('applied');
  expect(state.row.arrival_date).toBeNull(); expect(state.row.stage).toBe('0');
  await getTasks(); expect(state.stages).toEqual(['not_arrived']);
  release(); const old = await oldRead;
  for(let i=0;i<8;i++) await Promise.resolve();
  await getTasks(); const fresh = await getCurrentUser();
  console.log('BINDING_STAGE_RACE',JSON.stringify({row:state.row,writes:state.writes,stages:state.stages,
    returnedOldStage:old?.onboarding?.stage,freshStage:fresh?.onboarding?.stage,
    needsPrompt:needsArrivalPrompt(fresh?.onboarding ?? null),actions:state.sent.map(body=>body.action)}));
  expect(fresh?.onboarding?.stage).toBe(0);
  expect(state.stages).toEqual(['not_arrived','not_arrived']);
  expect(needsArrivalPrompt(fresh?.onboarding ?? null)).toBe(true);
});
