// @vitest-environment jsdom
import { useState } from 'react';
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { afterEach, expect, it, vi } from 'vitest';
const state = vi.hoisted(() => ({province:'British Columbia',reads:0,actions:[] as any[]}));
vi.mock('@/hooks/useAuthUser', () => ({useAuthUser:() => ({data:{id:'synthetic-learn-owner'},isPending:false})}));
vi.mock('@/hooks/useLanguage', () => ({useLanguage:() => ({currentLanguage:'en'})}));
vi.mock('@/lib/analytics', () => ({trackCompanionActionResult:() => {}}));
vi.mock('@/lib/supabase/client', () => ({
  isSupabaseConfigured:() => true, getAuthUserId:async () => 'synthetic-learn-owner',
  createClient:() => ({from:(table:string) => {
    const query:any = {select:() => query,eq:() => query,
      maybeSingle:async () => {state.reads++;return {data:{province:state.province},error:null};},
      then:(yes:any,no:any) => Promise.resolve({data:[],error:null}).then(yes,no)};
    return query;
  }}),
}));
vi.mock('@/lib/sanity', () => ({
  isSanityConfigured:() => true, MODULES_LIST_QUERY:'synthetic-list', MODULE_DETAIL_QUERY:'',
  LESSON_DETAIL_QUERY:'', PRACTICES_BY_SUBMODULE_QUERY:'', LESSON_QUIZ_QUERY:'',
  mergeI18nOverlay:(row:any) => row,
  sanityClient:{fetch:async () => [
    {_id:'national',title:'National module',province:null,submodules:[]},
    {_id:'bc',title:'BC module',province:'British Columbia',submodules:[]},
    {_id:'on',title:'Ontario module',province:'Ontario',submodules:[]},
  ]},
}));
import { useModules } from '/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify-Web-App/root-companion-profile371-main-corrections/hooks/useLearn';
import { getModules } from '/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify-Web-App/root-companion-profile371-main-corrections/services/learn';
import { useTaskActionStore } from '/Volumes/Lexar/Dev.noindex/t3-worktrees/Unify-Web-App/root-companion-profile371-main-corrections/hooks/useTaskActions';
function LearnList() {
  const query=useModules();
  return <output data-testid="modules">{query.data?.map(row=>row._id).join(',') ?? 'loading'}</output>;
}
function RouteProbe() {
  const [learn,setLearn]=useState(true);
  const store=useTaskActionStore('companion');
  return <><button onClick={()=>setLearn(!learn)}>Navigate</button>
    <button onClick={()=>void store!.applyOperation('profile-review:synthetic',
      {type:'profile.update',field:'province',value:'Ontario',expected_revision:1},
      {kind:'approved_proposal',proposal_id:'synthetic-approved',proposal_revision:1})}>Save province</button>
    {learn?<LearnList/>:<span>Companion route</span>}</>;
}
afterEach(() => {cleanup();vi.unstubAllGlobals();});
it('refreshes the recently viewed Learn list after a supported province save', async () => {
  const qc=new QueryClient({defaultOptions:{queries:{staleTime:60000,retry:false,gcTime:Infinity}}});
  state.province='British Columbia';state.reads=0;state.actions=[];
  vi.stubGlobal('fetch', async (url:any,init:any) => {
    expect(url).toBe('/api/companion/actions');
    const body=JSON.parse(init.body);state.actions.push(body);
    expect(body.action).toBe('apply');expect(body.operations[0].value).toBe('Ontario');
    state.province='Ontario';
    return {status:200,json:async () => ({replayed:false,receipt:{
      operation_id:body.operation_id,operation_type:'profile.update',created_at:new Date().toISOString(),
      kind:'change',undo_of:null,task_ref:null,before_revision:1,after_revision:2,
      undone_by:null,current:true,undoable:true,profile:{field:'province',before:'British Columbia',after:'Ontario'},
    }})};
  });
  render(<QueryClientProvider client={qc}><RouteProbe/></QueryClientProvider>);
  await waitFor(()=>expect(screen.getByTestId('modules').textContent).toBe('national,bc'));
  fireEvent.click(screen.getByText('Navigate'));
  expect(screen.queryByTestId('modules')).toBeNull();
  await act(async()=>{fireEvent.click(screen.getByText('Save province'));});
  expect(state.province).toBe('Ontario');expect(state.actions).toHaveLength(1);
  const direct=await getModules('en');
  expect(direct.map(row=>row._id)).toEqual(['national','on']);
  fireEvent.click(screen.getByText('Navigate'));
  await act(async()=>{for(let i=0;i<8;i++) await Promise.resolve();});
  const cached=qc.getQueryState(['modules','en']);
  console.log('BINDING_LEARN_REFRESH',JSON.stringify({province:state.province,rendered:screen.getByTestId('modules').textContent,
    direct:direct.map(row=>row._id),isInvalidated:cached?.isInvalidated,provinceReads:state.reads,actionCount:state.actions.length}));
  const staleRendered=screen.getByTestId('modules').textContent;
  // Positive control: the real query and service update when their root is invalidated.
  await act(async()=>{await qc.invalidateQueries({queryKey:['modules']});});
  await waitFor(()=>expect(screen.getByTestId('modules').textContent).toBe('national,on'));
  expect(state.actions).toHaveLength(1);
  try {expect(staleRendered).toBe('national,on');}
  finally {qc.clear();}
});
